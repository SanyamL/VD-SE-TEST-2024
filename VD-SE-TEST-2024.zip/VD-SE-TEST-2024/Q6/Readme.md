Solution Approach
This problem can be solved efficiently using Floyd's Tortoise and Hare Algorithm (Cycle Detection). 
The algorithm is based on cycle detection in linked lists, and it uses two pointers without needing extra space.

Approach Details:
Phase 1: Cycle Detection
Treat the array as a linked list, where the value at each index is the pointer to the next node (the value at the index points to the next index).
We use two pointers, tortoise (slow pointer) and hare (fast pointer), to traverse the array. Since there is a duplicate number, it will create a cycle in this "list".
Move tortoise one step at a time and hare two steps at a time. They will eventually meet inside the cycle.

Phase 2: Finding the Duplicate
After detecting the cycle, reset one of the pointers (tortoise) to the start of the array.
Move both pointers one step at a time. The point where the two pointers meet again is the duplicate number.

```bash
python main.py