def findDuplicate(nums):
    ''' Function to find duplicates in a list using Floyd's Tortoise and Hare algorithm'''
    
    # Step 1: Use Floyd's Tortoise and Hare algorithm to find the cycle
    tortoise = hare = nums[0]

    # Phase 1: Move tortoise one step at a time, hare two steps
    while True:
        tortoise = nums[tortoise]
        hare = nums[nums[hare]]
        if tortoise == hare:
            break

    # Phase 2: Find the entrance to the cycle
    tortoise = nums[0]
    while tortoise != hare:
        tortoise = nums[tortoise]
        hare = nums[hare]

    return hare

# Example usage
nums = [1, 3, 4, 2, 2]
print(findDuplicate(nums))  # Output: 2
