# Customer Orders Django Project

This is a Django project that displays the top 5 customers who have spent the most in the last 6 months. The project includes the following features:

- A model for `Order` which tracks customer orders.
- A view to calculate and display the top 5 customers by total spending.
- A template to render the data in an HTML table.

## Features

- **Top Customers**: Retrieves the top 5 customers who have spent the most in the last 6 months.
- **Admin Panel**: Manage orders and customers through Django's built-in admin interface.
  
## Setup Instructions

### 1. Clone the Repository

```bash
pip install -r requirements.txt
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver


# To access Admin portal
http://127.0.0.1:8000/admin/


# To view Top 5 Customers
http://127.0.0.1:8000/orders/top-customers/
