from django.shortcuts import render
from .models import Order

def top_customers_view(request):
    """
    This view function retrieves the top customers based on their orders.

    Parameters:
    request (HttpRequest): The request object that contains information about the client's request.

    Returns:
    HttpResponse: A rendered response object that displays the top customers in a template.
    """
    top_customers = Order.top_customers()
    return render(request, 'top_customers.html', {'top_customers': top_customers})
