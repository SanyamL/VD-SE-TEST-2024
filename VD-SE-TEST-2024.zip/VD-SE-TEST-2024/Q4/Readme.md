# Rate Limiter

This is a simple implementation of a rate limiter in Python that limits the number of requests a user can make within a given time window. Each user is allowed to make a maximum of 5 requests per minute.

## Features

- Limits user requests to a defined maximum within a specific time window.
- Thread-safe for concurrent environments.
- Easy to use and integrate into existing applications.

## Implementation Details

### Class: `RateLimiter`

- **Constructor: `__init__(self, max_requests: int, time_window: int)`**
    - `max_requests`: Maximum number of requests allowed per user within the time window.
    - `time_window`: Time window in seconds (e.g., 60 seconds for one minute).

- **Method: `allow_request(self, user_id: str) -> bool`**
    - Takes a `user_id` as an argument and returns:
        - `True` if the request is allowed.
        - `False` if the request is denied due to exceeding the rate limit.

### Usage

To use the `RateLimiter`:

1. Create an instance of the `RateLimiter` with desired `max_requests` and `time_window`.
2. Call `allow_request(user_id)` to check if a request can be made.

### Example

```python
rate_limiter = RateLimiter(max_requests=5, time_window=60)

user_id = "user1"
for i in range(10):
    if rate_limiter.allow_request(user_id):
        print(f"Request {i+1} allowed for {user_id}")
    else:
        print(f"Request {i+1} denied for {user_id}")
    time.sleep(10)
