import time
import threading
from collections import defaultdict

class RateLimiter:
    def __init__(self, max_requests: int, time_window: int):
        """
        Initialize a RateLimiter instance.
        This class implements a rate limiting mechanism to control the number of requests
        a user can make within a specified time window.
        Parameters:
        max_requests (int): The maximum number of requests allowed within the time window.
        time_window (int): The duration of the time window in seconds.
        Attributes:
        max_requests (int): The maximum number of requests allowed within the time window.
        time_window (int): The duration of the time window in seconds.
        user_requests (defaultdict): A dictionary to store the timestamps of requests made by each user.
        lock (threading.Lock): A lock object to ensure thread-safe access to the user_requests dictionary.
        """
        self.max_requests = max_requests
        self.time_window = time_window  # in seconds
        self.user_requests = defaultdict(list)
        self.lock = threading.Lock()

    def allow_request(self, user_id: str) -> bool:
        with self.lock:
            current_time = time.time()
            # Remove timestamps that are outside the time window
            self.user_requests[user_id] = [
                timestamp for timestamp in self.user_requests[user_id]
                if timestamp > current_time - self.time_window
            ]
            if len(self.user_requests[user_id]) < self.max_requests:
                self.user_requests[user_id].append(current_time)
                return True
            else:
                return False




# Example usage
if __name__ == "__main__":
    rate_limiter = RateLimiter(max_requests=5, time_window=60)

    # Simulate requests
    user_id = "user1"
    for i in range(10):
        if rate_limiter.allow_request(user_id):
            print(f"Request {i+1} allowed for {user_id}")
        else:
            print(f"Request {i+1} denied for {user_id}")
        time.sleep(1)  # Simulate time between requests
