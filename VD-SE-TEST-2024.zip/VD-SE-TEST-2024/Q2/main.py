import pandas as pd
import re

def validateEmail(email):
    """Validate the email format using a regex."""
    email_regex = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
    return re.match(email_regex, email) is not None

def cleanUserData(input_file, output_file):
    # Read the CSV file into a DataFrame
    df = pd.read_csv(input_file)
    
    # Remove duplicate entries based on 'user_id'
    df_cleaned = df.drop_duplicates(subset='user_id')
    
    # Filter out rows with invalid email formats
    df_cleaned = df_cleaned[df_cleaned['email'].apply(validateEmail)]
    
    # Write the cleaned data to a new CSV file
    df_cleaned.to_csv(output_file, index=False)

if __name__ == "__main__":
    input_file = 'inputData.csv'    # Replace with your input CSV file
    output_file = 'outputData.csv'    # Replace with your output CSV file
    cleanUserData(input_file, output_file)

    print(f"Cleaned data has been written to {output_file}.")
