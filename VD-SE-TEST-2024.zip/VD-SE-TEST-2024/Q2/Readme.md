# User Data Cleaner

## Description
This project reads a CSV file containing user data, removes duplicate entries based on `user_id`, filters out rows with invalid email formats, and writes the cleaned data to a new CSV file. The project uses Python with the `pandas` library for data manipulation and `re` for regular expression-based email validation.

## Prerequisites
Before you begin, ensure you have Python installed on your system. This project requires Python 3.6 or higher.

## Files Included
- `inputData.csv`: Sample input CSV file with user data.
- `main.py`: Python script to clean the data.
- `requirements.txt`: File listing the dependencies for the project.

## Requirements
Install the dependencies by running the following command:

```bash
python main.py