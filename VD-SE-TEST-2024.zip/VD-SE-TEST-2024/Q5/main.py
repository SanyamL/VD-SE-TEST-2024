from typing import List, Dict, Callable, Any

def aggregate_data(data: List[Dict[str, Any]], key: str, aggregator: Callable) -> Dict[str, Any]:
    """
    Aggregates values from a list of dictionaries based on a specified key.

    Args:
        data (List[Dict[str, Any]]): A list of dictionaries to aggregate.
        key (str): The key to group the dictionaries by.
        aggregator (Callable): A function that takes a list of values and returns a single aggregated value.

    Returns:
        Dict[str, Any]: A dictionary with keys as the unique values of the specified key
                        and values as the aggregated results.
    """
    aggregated_result = {}

    for entry in data:
        group_key = entry[key]
        value = entry.get('value', 0)

        if group_key in aggregated_result:
            aggregated_result[group_key].append(value)
        else:
            aggregated_result[group_key] = [value]

    # Apply the aggregator function to each group
    for group_key in aggregated_result:
        aggregated_result[group_key] = aggregator(aggregated_result[group_key])

    return aggregated_result

if __name__ == '__main__':
    data = [
        {'category': 'A', 'value': 10},
        {'category': 'B', 'value': 20},
        {'category': 'A', 'value': 30}
    ]

    result = aggregate_data(data, 'category', sum)
    print(result)  # Output: {'A': 40, 'B': 20}
