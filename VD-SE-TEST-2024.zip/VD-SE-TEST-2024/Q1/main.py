import requests
from bs4 import BeautifulSoup

# URL of the news website to scrape
URL = 'https://edition.cnn.com/world'

# Function to scrape the news headlines and URLs
def scrape_news(url):
    # Send a request to the webpage
    response = requests.get(url)

    if response.status_code != 200:
        print(f"Failed to retrieve the page. Status code: {response.status_code}")
        return []

    # Parse the content of the request with BeautifulSoup
    soup = BeautifulSoup(response.content, 'html.parser')

    # Find all the articles' titles and links (adjust the selectors if needed)
    # CNN has a complex structure, so we are targeting a more specific section
    articles = soup.find_all('h3', class_='cd__headline')

    # Extract the title and URLs
    news_list = []
    for article in articles:
        title = article.get_text(strip=True)
        link = article.find('a')['href']
        
        # Check if the link is relative or absolute
        if link.startswith('/'):
            link = f"https://edition.cnn.com{link}"
        
        news_list.append({'title': title, 'url': link})

    return news_list

if __name__ == "__main__":
    # Scrape the news
    latest_news = scrape_news(URL)

    if not latest_news:
        print("No articles found or failed to scrape.")
    else:
        # Display the scraped news titles and URLs
        for idx, news in enumerate(latest_news):
            print(f"{idx+1}. {news['title']}")
            print(f"   URL: {news['url']}\n")
