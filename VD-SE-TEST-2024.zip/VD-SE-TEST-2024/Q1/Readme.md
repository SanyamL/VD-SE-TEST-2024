*** Web Scraper for Latest CNN News Articles ***

*** Overview ***

This Python script scrapes the latest article titles and URLs from the CNN World News section using BeautifulSoup and requests. It sends a request to CNN’s world news page, parses the HTML content, extracts article titles and their URLs, and displays them in a structured format.

*** Features ***

Scrapes the latest news headlines from CNN.
Extracts and prints the corresponding article URLs.
Handles CNN's current HTML structure.

*** Requirements ***

To run this script, you will need to install the following dependencies:

requests: A Python library for making HTTP requests.
beautifulsoup4: A Python library for parsing HTML and XML documents.

*** Example ***

1. Biden says US working 'round-the-clock' to assist Ukraine in its counteroffensive
   URL: https://edition.cnn.com/2024/09/21/politics/biden-ukraine-counteroffensive/index.html

2. US accuses Russia of targeting civilians with cluster bombs in Ukraine
   URL: https://edition.cnn.com/2024/09/21/world/russia-ukraine-war-civilian-casualties-intl/index.html

3. Global economies brace for impact as China’s slowdown deepens
   URL: https://edition.cnn.com/2024/09/21/business/china-economy-impact-intl/index.html

4. Thousands evacuated in Greece as wildfire threatens Athens suburbs
   URL: https://edition.cnn.com/2024/09/21/europe/greece-wildfire-athens-intl/index.html


```bash

pip install -r requirements.txt

python main.py